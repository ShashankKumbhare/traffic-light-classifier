# traffic-light-classifier

A computer vision project 'Traffic Light Classification' to classify traffic light signals as either red, yellow or green.  

The project was the final project of the online nanodegree program 'Intro to Self Driving Cars' offered by 'udacity.com'.  

This project utilizes the knowledge of computer vision and machine learning techniques to classify the traffic signal light images as either red, green, or yellow.  

